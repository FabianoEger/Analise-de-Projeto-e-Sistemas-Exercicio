package utils;

import java.util.Scanner;

public class Leitura {
	
	private static Scanner entrada;
	public static String lerString(){
		entrada = new Scanner (System.in);
		String x = entrada.nextLine();
		return x;
	}
	public static int lerInt(){
		String x = lerString();
		int y = Integer.parseInt(x);
		return y;
	}
	public static double lerDouble(){
		String x = lerString();
		double y = Double.parseDouble(x);
		return y;
	}

}
