package sacometro;

public class Dinheiro {

	private int valor;

	public int getValor() {
		return valor;
	}

	public void setValor(int dinheiro) {
		this.valor = dinheiro;
	}

	public int dinheiroConta() {
		Dinheiro dinheiro = new Dinheiro();
		dinheiro.setValor(10000);
		return dinheiro.getValor();
	}

}
