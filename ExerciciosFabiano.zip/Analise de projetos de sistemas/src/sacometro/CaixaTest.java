package sacometro;

import org.junit.Assert;
import org.junit.Test;

public class CaixaTest {

	@Test
	public void testCaixa() {
		Caixa caixa = new Caixa();
		Dinheiro dinheiro = new Dinheiro();
		dinheiro.setValor(caixa.getVlSaque());
		caixa.saque(dinheiro);
		Assert.assertEquals(caixa.getVlSaque(), caixa.getVlSaque());
	}

}
