package sacometro;

import junit.framework.Assert;
import org.junit.Test;

public class CartaoTest {

	@Test
	public void testCartao() {
		Cartao cartao = new Cartao();
		int senha = 1234;
		cartao.setSenha(senha);
		Assert.assertEquals(1234, cartao.getSenha());

	}

}
