package sacometro;

import utils.Leitura;

public class Caixa {
	private int vlSaque;

	public int getVlSaque() {
		return vlSaque;
	}

	public void setVlSaque(int vlSaque) {
		this.vlSaque = vlSaque;
	}

	public void saque(Dinheiro dinheiro) {
		System.out.println("#### SEU SALDO ATUAL � DE:"
				+ dinheiro.dinheiroConta() + "R$ ######");
		System.out.println("#### INFORME VALOR QUE DESEJA SACAR ####");
		System.out
				.println("LEMBRANDO, ESTE CAIXA S� POSSUI NOTAS DE 50R$ E 100R$");
		vlSaque = Leitura.lerInt();
		int money = dinheiro.dinheiroConta();
		if (money >= vlSaque && vlSaque % 50 == 0) {
			Cartao cartao = new Cartao();
			cartao.validaSenha();
			System.out.println("### VOC� SACOU " + vlSaque
					+ "R$ DA SUA CONTA ###");
			int saldoAtual = money - vlSaque;
			System.out.println("#### SALDO ATUAL � DE:" + saldoAtual
					+ "R$ ####");

		} else if (vlSaque % 50 > 0) {
			System.out
					.println("ESTE CAIXA SO ACEITA SAUQUES COM M�LTIPLOS DE 50!");
		} else {
			System.out.println("#### DINHEIRO INSUFICIENTE ####");
		}

	}

	public static void main(String[] args) {
		Caixa caixa = new Caixa();
		Dinheiro dinheiro = new Dinheiro();
		caixa.saque(dinheiro);
	}
}
