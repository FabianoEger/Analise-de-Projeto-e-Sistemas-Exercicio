package sacometro;

import utils.*;

public class Cartao {

	private int senha;

	public int getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}

	public void validaSenha() {
		Cartao cartao = new Cartao();
		System.out.println("#### INFORME SENHA ####");
		int senha = Leitura.lerInt();
		cartao.setSenha(senha);
	}

}
