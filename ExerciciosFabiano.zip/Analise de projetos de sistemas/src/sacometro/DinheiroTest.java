package sacometro;

import junit.framework.Assert;

import org.junit.Test;

public class DinheiroTest {

	@Test
	public void testDinheiro() {
		Dinheiro dinheiro = new Dinheiro();
		Assert.assertEquals(10000, dinheiro.dinheiroConta());
	}

}
