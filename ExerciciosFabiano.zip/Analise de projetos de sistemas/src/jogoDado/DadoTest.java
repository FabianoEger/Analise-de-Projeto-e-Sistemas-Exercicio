package jogoDado;

import org.junit.Test;

import junit.framework.TestCase;

public class DadoTest extends TestCase {
	
	@Test
	public void testLancar(){
		Dado dado = new Dado();
		int result = dado.getLancar(dado);
		
		if (result >= 1 && result <= 6) {
			assertTrue(true);
		}
	}

}