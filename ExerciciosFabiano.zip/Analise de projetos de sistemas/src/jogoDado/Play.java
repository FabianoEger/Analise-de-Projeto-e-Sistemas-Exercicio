package jogoDado;

public class Play {

	private Dado primeiroDado;
	private Dado segundoDado;

	public Dado getPrimeiroDado() {
		return primeiroDado;
	}

	public void setPrimeiroDado(Dado primeiroDado) {
		this.primeiroDado = primeiroDado;
	}

	public Dado getSegundoDado() {
		return segundoDado;
	}

	public void setSegundoDado(Dado segundoDado) {
		this.segundoDado = segundoDado;
	}

	public boolean jogar() {
		int a = getPrimeiroDado().getLancar(getPrimeiroDado());
		int b = getSegundoDado().getLancar(getSegundoDado());
		int soma = a + b;
		System.out.println("Face do primeiro dado " + a + "\n"
				+ "Face do segundo dado " + b);
		if (soma == 7) {
			System.out.println("Voc� Ganhou! " + soma);
			return true;
		} else {
			System.out.println("V�ce perdeu! " + soma);
			return false;
		}

	}

	public static void main(String[] args) {
		Play play = new Play();
		play.primeiroDado = new Dado();
		play.segundoDado = new Dado();
		play.jogar();
	}

}
