package jogoDado;

import java.util.Random;

public class Dado {

	private int face;

	public int getValor() {
		return face;
	}

	public void setValor(int face) {
		this.face = face;
		
	}

	public int getLancar(Dado dado) {
		Random gerador = new Random();
		int lancar = gerador.nextInt(6) + 1;
		dado.setValor(lancar);
		return dado.getValor();

	}

}
