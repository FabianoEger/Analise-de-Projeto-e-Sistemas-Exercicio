package jogoDado;

import static org.junit.Assert.*;

import org.junit.Test;

public class PlayTest {

	@Test
	public void testPlay() {
		Play play = new Play();
		play.setPrimeiroDado(new Dado());
		play.setSegundoDado(new Dado());

		boolean somaTest = play.jogar();

		if (somaTest == true || somaTest == false) {
			assertTrue(true);
		}
	}

}
